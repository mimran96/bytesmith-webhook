export default async function handler(req, res) {
  if (req.method === "GET") {
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    if (mode === "subscribe" && token === "bytesmith123") {
      return res.status(200).send(challenge);
    } else {
      return res.sendStatus(403);
    }
  }

  if (req.method === "POST") {
    try {
      await fetch("https://hook.eu1.make.com/pl5z8xppm2x6yp38pvud9hk15jtoednz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(req.body)
      });

      return res.sendStatus(200);
    } catch (err) {
      console.error("Forwarding error:", err);
      return res.sendStatus(500);
    }
  }

  return res.sendStatus(405);
}
